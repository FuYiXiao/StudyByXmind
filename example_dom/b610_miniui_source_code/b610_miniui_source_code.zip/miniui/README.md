# 修改记录

### 版本号：1.0.005

### 发布日期：2015-08-6

## 修改内容：
1. datapicker:增加对2011.11.02格式的支持。
2. tree:CheckRecursive=true,在filter后，点击父节点后，对于过滤掉的节点，不会被选中。
3. treeselect:CheckRecursive=true,且查询操作后，点击父节点后，子节点全选，过滤掉的节点不出现在输入框当中。
4. datagrid:在ie6,ie8兼容模式下，当没有数据时，没有横向滚动条。