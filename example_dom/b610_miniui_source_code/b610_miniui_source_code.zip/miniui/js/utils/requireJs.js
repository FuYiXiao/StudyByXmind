/**
 * Created by pzf on 2014/11/10.
 */
if (typeof define === 'function' && define.amd) {
    define('miniui', ['jquery'], function() {
        return mini;
    });
}